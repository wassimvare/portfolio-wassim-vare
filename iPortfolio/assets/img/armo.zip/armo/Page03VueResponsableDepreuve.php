
<?php 
include("bar.php");


echo'
<div style= "border : 1px dashed red; width : 300px;"> 
<p>Etablissement : '.$codeE.'</p>
<p>Session : '.$annee.'</p>
</div>
';
?>


<div style="margin-left:auto;margin-right:auto;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:70%;">
<form method="POST" action="saisie-du-nombre-de-note.php">
<h1 style="text-align:center;margin-top:5%;font-family:arial;">nombre de notes</h1> 

<br><b<p>Saissez ici lenombre de note:</p>
<input type="text" name="nb" >

<br><br>
<input type="submit" style="background-color:orange;font-family:arial;padding:15px;border-radius:25px;border:none;">
<br><br>
</form>
</div>

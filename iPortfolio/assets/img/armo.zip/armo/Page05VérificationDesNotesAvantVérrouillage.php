<img src="logoHORMOCCF.gif" style="margin-left:41%;margin-right:31%;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:250px;"> 
<a href="Page06CorrectionDuneNote.php">Page6</a>
<p style="color : red">Deconnexion </p>
</div>


<div style="margin-left:auto;margin-right:auto;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:70%;">
<form >
<br><b<p>Vous avez saisie les valeurs suivantes</p>
<p><input></p>
<p><input></p>
<br><br>
<input type="submit" style="background-color:orange;font-family:arial;padding:15px;border-radius:25px;border:none;">
<br><br>
</form>
</div>
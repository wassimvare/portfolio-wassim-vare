
<img src="logoHORMOCCF.gif" style="margin-left:45%;margin-left:43%;margin-right:35%;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:250px;">">
<div style= "border : 1px dashed red; width : 400px;margin-left: auto;margin-right: auto;"> 
<center>
<p>Fonction indisponible <p/>
<a href="Page01Connexion.php">Retour a la page de connection</a>
<center/>
</div>

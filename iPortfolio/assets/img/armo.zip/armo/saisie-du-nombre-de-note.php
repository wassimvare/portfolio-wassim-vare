<?php 
include("bar.php");


echo'
<div style= "border : 1px dashed red; width : 300px;"> 
<p>Etablissement : '.$codeE.'</p>
<p>Session : '.$annee.'</p>
</div>
';
?>


<div style="margin-left:auto;margin-right:auto;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:70%;">
<form method="POST" action="affichage-note-moyenne.php">
<h1 style="text-align:center;margin-top:5%;font-family:arial;">SAISIE DES DES RESULTATS D UN CCF</h1> 

<br><b<p>Saissez ici les notes obtenues au CCF dans le désordre</p>


<?php  

$nb = $_POST['nb'];

for( $a=1; $a<=$nb; $a++)
{

echo '<p> Note eleve: '.$a.' <input type="text" name="Notes[]"><br><br></p>';
echo'<input type="hidden" name="nb" value="'.$nb.'">';
}

?>


<br><br>
<input type="submit" style="background-color:orange;font-family:arial;padding:15px;border-radius:25px;border:none;">
<br><br>
</form>
</div>

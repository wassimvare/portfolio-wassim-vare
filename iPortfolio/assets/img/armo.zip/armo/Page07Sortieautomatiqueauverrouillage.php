<img src="logoHORMOCCF.gif" style="margin-left:41%;margin-right:31%;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:250px;">
<h1 style="text-align:center;margin-top:5%;font-family:arial;">Connectez-vous</h1>
<a href="Page08Reconnexiondeletablissement.php">Page8</a>

<div style="margin-left:auto;margin-right:auto;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:300px;">
<form >
<br><b<p>Utilsateur:</p><input>

<p>Mot de passe</p><input type="password"> 
<br><br>
<input type="submit" style="background-color:orange;font-family:arial;padding:15px;border-radius:25px;border:none;">
<br><br>
</form>
</div>
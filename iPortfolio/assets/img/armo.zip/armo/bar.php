

<center><img src="logoHORMOCCF.gif" style="margin-left:43%;margin-right:35%;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:250px;">></center>

<br><br>
<a style="color:red;font-family:arial;text-decoration:none" href="Page01Connexion.php" >Deconnexion </a>
<br><br>


<?php

session_start();
$mm=$_SESSION['login'];
$annee = $_SESSION['annee'] ;
$codeE = $_SESSION['codeE'] ;
$codeEpreuve = $_SESSION['codeEpreuve'] ;
$numSection = $_SESSION['numSection'] ;
?>

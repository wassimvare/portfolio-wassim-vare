<?php 
include("bar.php");


echo'
<div style= "border : 1px dashed red; width : 300px;"> 
<p>Etablissement : '.$codeE.'</p>
<p>Session : '.$annee.'</p>
</div>
';
?>


<div style="padding: 14px ;margin-left:auto;margin-right:auto;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:70%;">
<p style="text-transform:uppercase; color:blue">vos mots de passes pour cette session</p>

<style>
table {margin-left:auto;margin-right : auto;border:1px solid black;border-collapse:collapse;}
td {border:1px solid black;border-collapse:collapse;}
th {border:1px solid black;border-collapse:collapse;}

</style>

<?php
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=armoccf;charset=utf8', 'root', '');
}
catch(Exception $erreur)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$erreur->getMessage());
}


// SELECT * FROM `utilisateur` WHERE `code_etab` LIKE '0692717d' AND `annee` = 2014 AND `role` LIKE 'EPREUV' 


/*

SELECT *
FROM utilisateur 
INNER JOIN section 
ON utilisateur.code_etab = section.numEtab
INNER JOIN epreuve
ON section.idSerie = epreuve.idSerie 

WHERE utilisateur.code_etab='$codeE' AND utilisateur.annee = '$datee' AND utilisateur.role LIKE 'EPREUV'

*/

// On récupère tout le contenu de la table Utilisateur
$requeteSQL = "


SELECT * FROM `utilisateur` INNER JOIN section 
ON utilisateur.numSection = section.numSection WHERE `code_etab` LIKE '$codeE' AND `annee` = $annee AND `role` LIKE 'EPREUV'

";




$reponse = $bdd->query($requeteSQL);

echo '

<table>

<tr>
<th>Section</th>
<th>Epreuve</th>
<th>Identifiant</th>
<th>Mot de passe</th>
</tr>



';

// On affiche chaque ligne une à une
while($donnees = $reponse->fetch()){

echo'
<tr>
<td><p>'.$donnees['nomSection'].'</p></td>
<td><p>'.$donnees['codeEpreuve'].'</p></td>
<td><p>'.$donnees['login'].'</p></td>
<td><p>'.$donnees['mdp'].'</p></td>

</tr>
';
}

echo'</table>';
?>

<p style="text-transform:uppercase; color:blue">information sur la cession</p>
<table>

<tr>
<th>Section</th>

<th>serie</th>
<th>Epreuve</th>
<th>nombres de candidats note</th>

<th>nom du responsable de l epreuve</th>

<th>mail du responsable</th>
<th>telephone du responsable</th>
<th>action</th>
</tr>



<?php

try
{
	// On se connecte à MySQL
	$bdd2 = new PDO('mysql:host=localhost;dbname=harmoccf_sylvain_theo;charset=utf8', 'root', '');
}
catch(Exception $erreur)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$erreur->getMessage());
}



/*

SELECT * FROM `utilisateur` 
INNER JOIN epreuve 
ON utilisateur.codeEpreuve = epreuve.codeEpreuve
INNER JOIN section 
ON utilisateur.numSection = section.numSection WHERE `code_etab` LIKE '0692717d' AND `annee` = 2014 AND `role` LIKE 'EPREUV'



SELECT * FROM utilisateur, epreuve ,section  , participer  WHERE utilisateur.code_etab LIKE '$codeE' AND
 utilisateur.annee  = '$annee' AND utilisateur.role LIKE 'EPREUV' 
AND section.idSerie = epreuve.idSerie AND section.numSection = epreuve.numSection AND participer.numSection = utilisateur.numSection  

*/

$requeteSQL2 = "
SELECT * FROM `utilisateur` 
INNER JOIN epreuve 
ON utilisateur.codeEpreuve = epreuve.codeEpreuve
INNER JOIN section 
ON utilisateur.numSection = section.numSection WHERE `code_etab` LIKE '$codeE' AND `annee` = '$annee' AND `role` LIKE 'EPREUV'

";




$reponse2 = $bdd2->query($requeteSQL2);


while($donnees2 = $reponse2->fetch()){
echo'

<form method="post" action="update.php">
<tr>
<td><p>'.$donnees2['nomSection'].'</p><input type="hidden" name="aa1" value="'.$donnees2['nomSection'].'"></td>
<td><p>'.$donnees2['idSerie'].'</p><input type="hidden"  name="aa2" value="'.$donnees2['idSerie'].'"></td>
<td><p>'.$donnees2['codeEpreuve'].' - '.$donnees2['nomEpreuve'].'</p><input type="hidden" name="aa3" value="'.$donnees2['codeEpreuve'].'"></td>
<td> <input name="a1"  type="text"></td>
<td><input name="a2"  type="text"></td>
<td> <input name="a3"  type="text"></td>
<td><input name="a4" type="text"> </td>
<td><input type="submit" name="a5" value="modifier"> </td>
</form>
</tr>
';
}


echo'
</table>





<p style="text-transform:uppercase; color:blue">Recapitulatif de la session</p>';














echo'

<table>

<tr>


<th>nb candidat</th>
<th>responsable</th>
<th>minimum</th>
<th>maximum</th>
<th>moyenne</th>
<th>moin de 8</th>
<th>8 a 10</th>
<th>10 a 12</th>
<th>+ 12</th>
<th>ecart type</th>


</tr>
';

try
{
	// On se connecte à MySQL
	$bdd23 = new PDO('mysql:host=localhost;dbname=harmoccf_sylvain_theo;charset=utf8', 'root', '');
}
catch(Exception $erreur)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$erreur->getMessage());
}



$requeteSQL23 = "SELECT * FROM restituer ,participer  WHERE restituer.annee='$annee' and restituer.codeEpreuve = participer.codeEpreuve 
and restituer.annee = participer.annee 
and restituer.numSection = participer.numSection ";

$reponse23 = $bdd23->query($requeteSQL23);
while($donnees23 = $reponse23->fetch()){
echo'
<tr>


<td>'.$donnees23['nbParticipant'].'</td>
<td>'.$donnees23['nom_resp'].'</td>
<td>'.$donnees23['Min'].'</td>
<td>'.$donnees23['Max'].'</td>
<td>'.$donnees23['Moy'].'</td>
<td>'.$donnees23['inf8'].'</td>
<td>'.$donnees23['inf10'].'</td>
<td>'.$donnees23['sup10'].'</td>
<td>'.$donnees23['sup12'].'</td>
<td>'.$donnees23['et'].'</td>


</tr>
';
}


























































try
{
	// On se connecte à MySQL
	$bdd23 = new PDO('mysql:host=localhost;dbname=harmoccf_sylvain_theo;charset=utf8', 'root', '');
}
catch(Exception $erreur)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$erreur->getMessage());
}



$requeteSQL23 = "


SELECT * FROM `utilisateur` 
INNER JOIN epreuve 
ON utilisateur.codeEpreuve = epreuve.codeEpreuve
INNER JOIN section 
ON utilisateur.numSection = section.numSection WHERE `code_etab` LIKE '$codeE' AND `annee` = '$annee' AND `role` LIKE 'EPREUV'

";
$reponse23 = $bdd23->query($requeteSQL23);
while($donnees23 = $reponse23->fetch()){
echo'

<p><strong>Serie : </strong> '.$donnees23['idSerie'].' <strong>     Epreuve : </strong> '.$donnees23['codeEpreuve'].' </p>
';
}



?>


</div>
<?php
echo 'Affichage de la table Utilisateur';
echo '<br />';

try
{
	// On se connecte � MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=armoccf;charset=utf8', 'root', '');
}
catch(Exception $erreur)
{
	// En cas d'erreur, on affiche un message et on arr�te tout
        die('Erreur : '.$erreur->getMessage());
}

// On r�cup�re tout le contenu de la table Utilisateur
$requeteSQL = "SELECT login, mdp, codeEpreuve, code_etab, numSection, annee, role, debut, fin FROM Utilisateur";
$reponse = $bdd->query($requeteSQL);

// On affiche chaque ligne une � une
while ($donnees = $reponse->fetch())
{
	echo $donnees['login'];
	echo '<br />';
}

$reponse->closeCursor(); // Termine le traitement de la requ�te

?>
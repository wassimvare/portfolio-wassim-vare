

 <a href="" ><img src="logoHORMOCCF.gif" style="margin-left:43%;margin-right:35%;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:250px;"></a>
<h1 style="text-align:center;margin-top:0%;font-family:arial;">Connectez-vous</h1>


<div style="margin-left:auto;margin-right:auto;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:300px;">
<form method="post">
<br><b<p>Utilsateur:</p><input type="text" name="user">

<p>Mot de passe</p><input type="password" name="password"> 
<br><br>
<input type="submit" style="background-color:orange;font-family:arial;padding:15px;border-radius:25px;border:none;" name="Michel">
<br><br>
</form>
</div>
<?php
if(isset($_POST['Michel'])){

$tttt = htmlentities($_POST["user"]);
$ssss = htmlentities($_POST["password"]);









/*



session_start();
$_SESSION['login'] = $tttt;


try
{
	// On se connecte à MySQL
	$bdd2 = new PDO('mysql:host=localhost;dbname=harmoccf_sylvain_theo;charset=utf8', 'root', '');
}
catch(Exception $erreur)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$erreur->getMessage());
}

// On récupère tout le contenu de la table Utilisateur
$requeteSQL = "SELECT * FROM utilisateur";
$reponse2 = $bdd2->query($requeteSQL);

// On affiche chaque ligne une à une
while ($donnees2 = $reponse2->fetch())
{
	
$_SESSION['codeE'] = $donnees2['code_etab'];
$_SESSION['annee'] = $donnees2['annee'];
$_SESSION['codeEpreuve'] = $donnees2['codeEpreuve'];
	
}

$reponse2->closeCursor(); // Termine le traitement de la requête









session_start();
$_SESSION['login'] = $tttt;
$_SESSION['codeE'] = $donnees2['code_etab'];
$_SESSION['annee'] = $donnees2['annee'];
$_SESSION['codeEpreuve'] = $donnees2['codeEpreuve'];
	


*/





















try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=armoccf;charset=utf8', 'root', '');
	
	
}
catch(Exception $erreur)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$erreur->getMessage());
}




















// On récupère tout le contenu de la table Utilisateur
$requeteSQL = "SELECT * FROM Utilisateur where login='$tttt' and mdp='$ssss' and role='admin'";
$reponse = $bdd->query($requeteSQL);



// On affiche chaque ligne une à une
if($donnees = $reponse->fetch()){
	
	
	

session_start();
$_SESSION['login'] = $tttt;
$_SESSION['codeE'] = $donnees['code_etab'];
$_SESSION['annee'] = $donnees['annee'];
$_SESSION['codeEpreuve'] = $donnees['codeEpreuve'];
$_SESSION['numSection'] = $donnees['numSection'];	

	echo '<p style="color:green;text-align:center;font-family:arial">connecte</p>';
    header('Location: PageConnexionAdministration.php');
	
}


	
	
$reponse->closeCursor(); // Termine le traitement de la requête





















// On récupère tout le contenu de la table Utilisateur
$requeteSQL = "SELECT * FROM Utilisateur where login='$tttt' and mdp='$ssss' and role='etabli'";
$reponse = $bdd->query($requeteSQL);



// On affiche chaque ligne une à une
if($donnees = $reponse->fetch()){
	
	session_start();
$_SESSION['login'] = $tttt;
$_SESSION['codeE'] = $donnees['code_etab'];
$_SESSION['annee'] = $donnees['annee'];
$_SESSION['codeEpreuve'] = $donnees['codeEpreuve'];
$_SESSION['numSection'] = $donnees['numSection'];	

	echo '<p style="color:green;text-align:center;font-family:arial">connecte</p>';
    header('Location: Page02VueEtablissementAvant.php');
}

	
	
$reponse->closeCursor(); // Termine le traitement de la requête

























// On récupère tout le contenu de la table Utilisateur
$requeteSQL = "SELECT * FROM Utilisateur where login='$tttt' and mdp='$ssss' and role='EPREUV'";
$reponse = $bdd->query($requeteSQL);



// On affiche chaque ligne une à une
if($donnees = $reponse->fetch()){


session_start();
$_SESSION['login'] = $tttt;
$_SESSION['codeE'] = $donnees['code_etab'];
$_SESSION['annee'] = $donnees['annee'];
$_SESSION['codeEpreuve'] = $donnees['codeEpreuve'];
$_SESSION['numSection'] = $donnees['numSection'];
	echo '<p style="color:green;text-align:center;font-family:arial">connecte</p>';
    header('Location: Page03VueResponsableDepreuve.php');
}


	
$reponse->closeCursor(); // Termine le traitement de la requête



if($donnees = !$reponse->fetch()){ echo'<p style="color:red;text-align:center;font-family:arial">Mot de passe ou identifant incorrect</p>';}








}

?>
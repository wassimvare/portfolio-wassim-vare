<?php 
include("bar.php");


echo'
<div style= "border : 1px dashed red; width : 300px;"> 
<p>Etablissement : '.$codeE.'</p>
<p>Session : '.$annee.'</p>
</div>
';
?>

<div style="margin-left:auto;margin-right:auto;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:300px;">
<form >
<p>vous avez saisie les valeurs suivantes:</p>

<?php  
$nb = $_POST['nb'];
$educationValues = $_POST['Notes'];  //Returns an array
// echo '<p> Note eleve: '. print_r($educationValues).' </p><br><br>';



 /* $array = array( 'fruits' => array( $educationValues) );



	$x=array ('one' => $educationValues, 'two' => $educationValues, 'three' => $educationValues, 'four' => $educationValues) ;
	foreach ($x as $value)
	  {
	  echo "Le jour est ".$value. " <br/> " ;
	  }
	*/
	


$array = array( 'Mes notes' => $educationValues );

foreach( $array as $key => $value )
{
   echo $key . ': <br />';
   
     foreach( $value as $valeurs )
       echo '  ' . $valeurs . '<br />';
	   
   
  echo '<br />';
}




// moyenne 
$somme_notes = 0;
$i = 0;
foreach($educationValues as $cle=>$valeur)
{
$i++; // On incrémente la variable qui nous dit combien de tour on fait
$somme_notes+=$valeur;
// équivaut a $somme_notes = $somme_notes + $valeur
}
$moyenne = $somme_notes / $i;
echo "moyenne: ".$moyenne;
 
 
 echo"<br><br>";
 // note eleve
 

$dep=0;
foreach($educationValues as $valeur)
{	
if($dep < $valeur){
	$max=$valeur;
	$dep=$valeur;
}}
echo "note la plus elev&eacute; : ".$max;
echo "<br><br>";






$du=$max;
foreach($educationValues as $valeur)
{	
if($valeur < $du){
	$ma=$valeur;
	$du=$valeur;
}}
echo "note la plus basse : ".$ma;
echo "<br><br>";








$ee=1;       
foreach($educationValues as $valeur){
    $ecart_donnee = $valeur - $moyenne; 
	$ee= $ecart_donnee + $ee;
}   
$ecart = ($ecart_donnee / $ee)*($ecart_donnee / $ee); 
$tt= $ecart/2;
echo "ecart type est : " . $tt;


//nombre entre


echo "<br><br>";
$depp=0;
foreach($educationValues as $valeur)
{	
if($valeur < 8){
	$depp=$depp +1;
}
}
echo "note entre 0 et 8 : ".$depp;









echo "<br><br>";
$depp=0;
foreach($educationValues as $valeur)
{	
if($valeur >= 8 &&  $valeur<=10){
	$depp=$depp +1;
}
}
echo "note entre 8,10: ".$depp;







echo "<br><br>";
$depp=0;
foreach($educationValues as $valeur)
{	
if($valeur >= 10 &&  $valeur<=12){
	$depp=$depp +1;
}
}
echo "note entre 10,12: ".$depp;
echo "<br><br>";











$depp=0;
foreach($educationValues as $valeur)
{	
if($valeur > 12){
	$depp=$depp +1;
}
}
echo "note superieur 12: ".$depp;
echo "<br><br>";








?>


<br><br>
<a href="Page03VueResponsableDepreuve.php">corriger</a>
<br><br>
<input type="submit"  value="verouiller">
</form>
</div>
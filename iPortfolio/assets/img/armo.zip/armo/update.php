
<?php

include('bar.php');

?>


<?php

if(isset($_POST['a5'])){
	
$a1=	$_POST['a1'];
$a2=	$_POST['a2'];
$a3=	$_POST['a3'];
$a4=	$_POST['a4'];
	



$aa1=	$_POST['nomSection'];
$aa2=	$_POST['idSerie'];
$aa3=	$_POST['codeEpreuve'];

	


/*

try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=harmoccf_sylvain_theo;charset=utf8', 'root', '');
}
catch(Exception $erreur)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$erreur->getMessage());
}

// On récupère tout le contenu de la table Utilisateur
$requeteSQL = "SELECT * FROM utilisateur ";
$reponse = $bdd->query($requeteSQL);

// On affiche chaque ligne une à une
while ($donnees = $reponse->fetch())
{
	$codeEpreuv_tableutilisateur = $donnees['codeEpreuve'];

}

$reponse->closeCursor(); // Termine le traitement de la requête


*/






// Accès à la base de données
try
{
	// On se connecte à MySQL
	$bdd = new PDO('mysql:host=localhost;dbname=armoccf;charset=utf8', 'root', '');
}
catch(Exception $erreur)
{
	// En cas d'erreur, on affiche un message et on arrête tout
        die('Erreur : '.$erreur->getMessage());
}

// Insertion dans la table Utilisateur
try
{
	//$requeteSQL = "INSERT INTO Utilisateur(login, mdp, codeEpreuve, code_etab, numSection, annee, role, debut) VALUES ('admin3', 'root',  NULL, NULL, NULL, NULL, 'admin', NULL, NULL)";
	
	$requeteSQL = "UPDATE participer set nbParticipant='$a1',nom_resp='$a2',mail_resp='$a3',tel_resp='$a4' WHERE   annee='$annee'
	and codeEpreuve='' and numSection='' ";
	
	echo $requeteSQL;
	
	$bdd->exec($requeteSQL);
	echo '<br><h1 style="color:green">update reussi</h1><br><a href="Page02VueEtablissementAvant.php">retour</a>';
	echo '<br />';
}



catch(Exception $erreur)
{
	// En cas d'erreur, on affiche un message et on arrête tout
	echo 'Erreur : '.$erreur->getMessage();
	die('Erreur : '.$erreur->getMessage());
}
}

?>
<?php 
include("bar.php");


echo'
<div style= "border : 1px dashed red; width : 300px;"> 
<p>Etablissement : '.$codeE.'</p>
<p>Session : '.$annee.'</p>
</div>
';
?>
<div style="margin-left:auto;margin-right:auto;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:300px;">
<form >
<p>vous avez saisie les valeurs suivantes:</p>
<p>15</p>
<p>8</p>

<br><br>
<input type="submit" style="background-color:orange;font-family:arial;padding:15px;border-radius:25px;border:none;" value="corriger">
<br><br>
<input type="submit" style="background-color:orange;font-family:arial;padding:15px;border-radius:25px;border:none;" value="verouiller">
</form>
</div>
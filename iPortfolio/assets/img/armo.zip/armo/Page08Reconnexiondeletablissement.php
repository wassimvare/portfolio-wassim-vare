<?php 
include("bar.php");


echo'
<div style= "border : 1px dashed red; width : 300px;"> 
<p>Etablissement : '.$codeE.'</p>
<p>Session : '.$annee.'</p>
</div>
';
?>
<h1 style="text-align:center;margin-top:5%;font-family:arial;">Connectez-vous</h1>


<div style="padding: 14px ;margin-left:auto;margin-right:auto;text-align:center;position:center;box-shadow:0px 0px 2px 0px ;width:70%;">
<p style="text-transform:uppercase; color:blue">vos mots de passes pour cette session</p>

<style>
table {margin-left:auto;margin-right : auto;border:1px solid black;border-collapse:collapse;}
td {border:1px solid black;border-collapse:collapse;}
th {border:1px solid black;border-collapse:collapse;}

</style>


<table>

<tr>
<th>Section</th>

<th>Epreuve</th>
<th>Identifiant</th>
<th>Mot de passe</th>
</tr>

<tr>
<td><p>test</p></td>
<td> <p>test</p></td>
<td> <p>test</p></td>
<td> <p>test</p></td>
</tr>
<tr>
<td> <p>test</p></td>
<td> <p>test</p></td>
<td><p>test</p> </td>
<td> <p>test</p></td>
</tr>
<tr>
<td> <p>test</p></td>
<td> <p>test</p></td>
<td><p>test</p> </td>
<td><p>test</p> </td>
</tr>
</table>


<p style="text-transform:uppercase; color:blue">information sur la cession</p>
<table>

<tr>
<th>Section</th>

<th>serie</th>
<th>Epreuve</th>
<th>nombres de candidats note</th>

<th>nom du responsable de l epreuve</th>

<th>mail du responsable</th>
<th>telephone du responsable</th>
<th>action</th>
</tr>

<tr>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td> <input type="text"></td>
<td><input type="text"></td>
<td> <input type="text"></td>
<td><input type="text"> </td>
<td><input type="submit"> </td>
</tr>
<tr>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td> <input type="text"></td>
<td><input type="text"></td>
<td> <input type="text"></td>
<td><input type="text"> </td>
<td><input type="submit"> </td>
</tr>
<tr>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td> <input type="text"></td>
<td><input type="text"></td>
<td> <input type="text"></td>
<td><input type="text"> </td>
<td><input type="submit"> </td>
</tr>

<tr>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td> <input type="text"></td>
<td><input type="text"></td>
<td> <input type="text"></td>
<td><input type="text"> </td>
<td><input type="submit"> </td>
</tr>

<tr>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td> <input type="text"></td>
<td><input type="text"></td>
<td> <input type="text"></td>
<td><input type="text"> </td>
<td><input type="submit"> </td>
</tr>
</table>

<p style="text-transform:uppercase; color:blue">Recapitulatif de la session</p>

<p><strong>Serie : </strong> test <strong>     Epreuve : </strong> test </p>

<table>

<tr>
<th>Section</th>

<th>serie</th>
<th>Epreuve</th>
<th>nombres de candidats note</th>

<th>nom du responsable de l epreuve</th>
<th>min</th>
<th>max</th>
<th>moyenne</th>
<th>moin de 8</th>
<th>8 à 10</th>
<th>10 à 12</th>
<th>plus de 12</th>
<th>ecart type</th>
</tr>

<tr>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>
<td><p>test</p></td>


</tr>

</table>

<p><strong>Serie : </strong> test <strong>     Epreuve : </strong> test </p>
<p><strong>Serie : </strong> test <strong>     Epreuve : </strong> test </p>
<p><strong>Serie : </strong> test <strong>     Epreuve : </strong> test </p>
<p><strong>Serie : </strong> test <strong>     Epreuve : </strong> test </p>



</div>
<?php
/**
 * Vue Pied de page
 *
 * PHP Version 7
 *
 * @category  PPE
 * @package   GSB
 * @author    beth sefer,Tsipora Schvarcz
 */
?>
        </div>
    </body>
</html>


